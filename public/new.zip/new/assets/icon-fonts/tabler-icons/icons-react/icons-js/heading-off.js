import * as React from "react";

function IconHeadingOff({
  size = 24,
  color = "currentColor",
  stroke = 2,
  ...props
}) {
  return <svg xmlns="http://www.w3.org/2000/svg" className="icon icon-tabler icon-tabler-heading-off" width={size} height={size} viewBox="0 0 24 24" strokeWidth={stroke} stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><desc>{"Download more icon variants from https://tabler-icons.io/i/heading-off"}</desc><path stroke="none" d="M0 0h24v24H0z" fill="none" /><path d="M7 12h5m4 0h1" /><path d="M7 7v12" /><path d="M17 5v8m0 4v2" /><path d="M15 19h4" /><path d="M15 5h4" /><path d="M5 19h4" /><path d="M3 3l18 18" /></svg>;
}

export default IconHeadingOff;